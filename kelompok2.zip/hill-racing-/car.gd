extends RigidBody2D

@export var engine_power: float = 100000.0
@export var flip_power: float = 30000.0

@onready var wheel = $"../Wheel"
@onready var wheel2 = $"../Wheel2"

func _physics_process(_delta):

	# MAJU
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		wheel.apply_torque(engine_power)
		wheel2.apply_torque(engine_power)

	# MUNDUR
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		wheel.apply_torque(-engine_power)
		wheel2.apply_torque(-engine_power)

	# BACKFLIP
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		apply_torque(-flip_power)

	# FRONTFLIP
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		apply_torque(flip_power)

	# Batasi putaran supaya tidak terlalu brutal
	angular_velocity = clamp(angular_velocity, -4.0, 4.0)
