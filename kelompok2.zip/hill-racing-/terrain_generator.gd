extends Node2D

@export var car_path: NodePath = NodePath("../Car")

@export var chunk_width: float = 4000.0
@export var point_distance: float = 100.0
@export var generate_ahead: float = 8000.0

@export var ground_y: float = 600.0
@export var ground_depth: float = 1000.0

var car: Node2D
var generated_until: float = 0.0

var noise := FastNoiseLite.new()


func _ready():
	car = get_node(car_path)

	noise.seed = randi()
	noise.frequency = 0.00055
	noise.fractal_octaves = 3
	noise.fractal_lacunarity = 2.0
	noise.fractal_gain = 0.5

	generated_until = -chunk_width

	while generated_until < car.global_position.x + generate_ahead:
		_generate_chunk()


func _process(_delta):
	if car == null:
		return

	while generated_until < car.global_position.x + generate_ahead:
		_generate_chunk()


func _generate_chunk():
	var start_x := generated_until
	var end_x := start_x + chunk_width

	var points := PackedVector2Array()

	var x := start_x

	while x <= end_x:

		var local_x := x - start_x

		# =====================================
		# BENTUK DASAR TERRAIN
		# =====================================

		var noise_value := noise.get_noise_1d(x)

		# Bukit utama
		var hills := noise_value * 220.0

		# Gelombang panjang
		var long_wave := sin(x * 0.0011) * 130.0

		# Gelombang kecil supaya tidak terlalu datar
		var small_wave := sin(x * 0.0035) * 35.0

		var y := ground_y + hills + long_wave + small_wave


		# =====================================
		# BIKIN BEBERAPA TANJAKAN LEBIH CURAM
		# =====================================

		var steep_wave := sin(x * 0.00075)

		if steep_wave > 0.65:
			y -= (steep_wave - 0.65) * 500.0


		# =====================================
		# LEMBAH PANJANG
		# =====================================

		var valley_wave := sin(x * 0.00042)

		if valley_wave < -0.65:
			y += (-valley_wave - 0.65) * 250.0


		points.append(
			Vector2(
				local_x,
				y
			)
		)

		x += point_distance


	# =====================================
	# TITIK TERAKHIR CHUNK
	# =====================================

	var final_noise := noise.get_noise_1d(end_x) * 220.0

	var final_long_wave := sin(end_x * 0.0011) * 130.0

	var final_small_wave := sin(end_x * 0.0035) * 35.0

	var final_steep := sin(end_x * 0.00075)

	if final_steep > 0.65:
		final_steep = (final_steep - 0.65) * 500.0
	else:
		final_steep = 0.0

	var final_valley := sin(end_x * 0.00042)

	if final_valley < -0.65:
		final_valley = (-final_valley - 0.65) * 250.0
	else:
		final_valley = 0.0

	var final_y := (
		ground_y
		+ final_noise
		+ final_long_wave
		+ final_small_wave
		- final_steep
		+ final_valley
	)

	points.append(
		Vector2(
			chunk_width,
			final_y
		)
	)


	# =====================================
	# BAGIAN BAWAH TANAH
	# =====================================

	points.append(
		Vector2(
			chunk_width,
			ground_y + ground_depth
		)
	)

	points.append(
		Vector2(
			0,
			ground_y + ground_depth
		)
	)


	# =====================================
	# STATIC BODY
	# =====================================

	var body := StaticBody2D.new()

	body.name = "TerrainChunk"

	body.position = Vector2(
		start_x,
		0
	)

	add_child(body)


	# =====================================
	# VISUAL TANAH
	# =====================================

	var polygon := Polygon2D.new()

	polygon.polygon = points

	polygon.color = Color(
		0.35,
		0.65,
		0.20
	)

	body.add_child(polygon)


	# =====================================
	# COLLISION
	# =====================================

	var collision := CollisionPolygon2D.new()

	collision.polygon = points

	body.add_child(collision)


	generated_until = end_x
